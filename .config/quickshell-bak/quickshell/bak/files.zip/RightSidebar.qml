import QtQuick
import QtQuick.Layouts
import qs.config
import qs.components
import qs.modules.notifications

SlideSidebar {
    side: "right"
    accent: Theme.neonMagenta
    title: "// RIGHT RAIL // NETWORK & ALERTS"
    expandedWidth: Config.rightSidebar.width
    wantsKeyboard: true

    WifiConnect { Layout.fillWidth: true }

    NotificationPanel { Layout.fillWidth: true }

    Item { Layout.fillHeight: true }

    PowerRow { Layout.fillWidth: true }
}
